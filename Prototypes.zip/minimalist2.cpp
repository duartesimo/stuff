// g++ -std=c++98 -Wall -Wextra -Werror minimalist2.cpp -o minimalist2
// Run: ./minimalist2 6667
// Test: nc 127.0.0.1 6667

#include <iostream>
#include <string>
#include <map>
#include <vector>
#include <cstring>      // memset, strerror
#include <cstdlib>      // atoi
#include <cerrno>
#include <unistd.h>     // close, read, write
#include <fcntl.h>      // fcntl
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h> // sockaddr_in
#include <arpa/inet.h>  // htonl, htons, inet_ntop
#include <poll.h>

static bool set_nonblock(int fd) {
    int flags = fcntl(fd, F_GETFL, 0);
    if (flags < 0) return false;
    return fcntl(fd, F_SETFL, flags | O_NONBLOCK) == 0;
}

int main(int argc, char** argv) {
    if (argc != 2) {
	std::cerr << "Usage: " << argv[0] << " <port>\n";
	return 1;
    }
    int port = std::atoi(argv[1]);

    // 1) listening socket (IPv4, TCP)
    int lfd = ::socket(AF_INET, SOCK_STREAM, 0);

    // allow quick restart on same port
    int yes = 1;
    ::setsockopt(lfd, SOL_SOCKET, SO_REUSEADDR, &yes, sizeof(yes));

    // bind 0.0.0.0:port
    sockaddr_in addr;
    std::memset(&addr, 0, sizeof(addr));
    addr.sin_family = AF_INET;
    addr.sin_addr.s_addr = htonl(INADDR_ANY);
    addr.sin_port = htons(port);
    ::bind(lfd, (sockaddr*)&addr, sizeof(addr));

    ::listen(lfd, 128);
    set_nonblock(lfd);

    std::cout << "listening on port " << port << " (non-blocking, poll)\n";

    // poll set
    std::vector<pollfd> pfds;
    pfds.push_back(pollfd());
    pfds[0].fd = lfd;
    pfds[0].events = POLLIN;
    pfds[0].revents = 0;

    // simple per-client state
    std::map<int, std::string> inbuf;   // partial input lines
    std::map<int, std::string> outbuf;  // pending writes

    // helpers to track POLLOUT on a client
    const short READ_EVENTS = POLLIN;                // always listen for reads
    const short READ_WRITE_EVENTS = POLLIN | POLLOUT; // add POLLOUT if we have data to send

    // returns index in pfds or -1
    //const int INVALID = -1;
    std::map<int, int> fd_index; // fd -> index in pfds
    fd_index[lfd] = 0;

    // utility to set events for a client fd
    std::string dummy; // to avoid map operator[] const issues
    (void)dummy;

    while (true) {
	int n = ::poll(&pfds[0], pfds.size(), 1000);
	if (n <= 0) continue; // timeout or interrupted -> loop

	// iterate backwards so we can erase safely
	for (int i = (int)pfds.size() - 1; i >= 0; --i) {
	    int fd = pfds[i].fd;
	    short rev = pfds[i].revents;
	    if (!rev) continue;

	    // A) front door ready: accept as many clients as are queued
	    if (fd == lfd && (rev & POLLIN)) {
		while (true) {
		    sockaddr_in caddr;
		    socklen_t clen = sizeof(caddr);
		    int cfd = ::accept(lfd, (sockaddr*)&caddr, &clen);
		    if (cfd < 0) {
			if (errno == EAGAIN || errno == EWOULDBLOCK) break;
			break; // minimal demo: ignore other errors
		    }
		    set_nonblock(cfd);

		    // add to poll set
		    pollfd p; p.fd = cfd; p.events = READ_EVENTS; p.revents = 0;
		    pfds.push_back(p);
		    fd_index[cfd] = (int)pfds.size() - 1;

		    // init buffers
		    inbuf[cfd] = "";
		    outbuf[cfd] = "";

		    // say hello
		    outbuf[cfd] += "Welcome! Type something and I'll echo it.\r\n";
		    pfds[fd_index[cfd]].events = READ_WRITE_EVENTS;
		}
	    }
	    // B) existing client: errors/hangups?
	    else if (fd != lfd && (rev & (POLLERR | POLLHUP | POLLNVAL))) {
		// cleanup
		::close(fd);
		// remove from pfds vector: swap with back then pop
		int last = (int)pfds.size() - 1;
		if (i != last) {
		    // update index map for the swapped fd
		    fd_index[pfds[last].fd] = i;
		    pfds[i] = pfds[last];
		}
		pfds.pop_back();
		fd_index.erase(fd);
		inbuf.erase(fd);
		outbuf.erase(fd);
	    }
	    // C) client readable
	    else if (fd != lfd && (rev & POLLIN)) {
		char buf[4096];
		while (true) {
		    ssize_t r = ::recv(fd, buf, sizeof(buf), 0);
		    if (r > 0) {
			inbuf[fd].append(buf, (size_t)r);
		    } else if (r == 0) {
			// peer closed
			::close(fd);
			int last = (int)pfds.size() - 1;
			if (i != last) { fd_index[pfds[last].fd] = i; pfds[i] = pfds[last]; }
			pfds.pop_back();
			fd_index.erase(fd);
			inbuf.erase(fd);
			outbuf.erase(fd);
			break;
		    } else {
			if (errno == EAGAIN || errno == EWOULDBLOCK) {
			    break; // no more to read now
			}
			// error -> close
			::close(fd);
			int last = (int)pfds.size() - 1;
			if (i != last) { fd_index[pfds[last].fd] = i; pfds[i] = pfds[last]; }
			pfds.pop_back();
			fd_index.erase(fd);
			inbuf.erase(fd);
			outbuf.erase(fd);
			break;
		    }
		}

		// turn complete lines into echoes
		if (fd_index.find(fd) != fd_index.end()) {
		    std::string& ib = inbuf[fd];
		    std::string::size_type pos = 0;
		    while (true) {
			std::string::size_type nl = ib.find('\n', pos);
			if (nl == std::string::npos) break;
			std::string line = ib.substr(pos, nl - pos);
			if (!line.empty() && line[line.size()-1] == '\r') line.erase(line.size()-1);

			// build reply
			outbuf[fd] += "you said: " + line + "\r\n";

			pos = nl + 1;
		    }
		    if (pos > 0) ib.erase(0, pos);

		    // if we queued anything, ensure POLLOUT is set
		    if (!outbuf[fd].empty()) {
			pfds[fd_index[fd]].events = READ_WRITE_EVENTS;
		    }
		}
	    }
	    // D) client writable
	    else if (fd != lfd && (rev & POLLOUT)) {
		std::string& ob = outbuf[fd];
		while (!ob.empty()) {
		    ssize_t nwr = ::send(fd, ob.data(), ob.size(), 0);
		    if (nwr > 0) {
			ob.erase(0, (size_t)nwr);
		    } else if (nwr < 0) {
			if (errno == EAGAIN || errno == EWOULDBLOCK) break; // try later
			// error -> close
			::close(fd);
			int last = (int)pfds.size() - 1;
			if (i != last) { fd_index[pfds[last].fd] = i; pfds[i] = pfds[last]; }
			pfds.pop_back();
			fd_index.erase(fd);
			inbuf.erase(fd);
			outbuf.erase(fd);
			break;
		    } else {
			// nwr == 0 -> treat as closed
			::close(fd);
			int last = (int)pfds.size() - 1;
			if (i != last) { fd_index[pfds[last].fd] = i; pfds[i] = pfds[last]; }
			pfds.pop_back();
			fd_index.erase(fd);
			inbuf.erase(fd);
			outbuf.erase(fd);
			break;
		    }
		}
		// if nothing left to send, drop POLLOUT
		if (fd_index.find(fd) != fd_index.end() && outbuf[fd].empty()) {
		    pfds[fd_index[fd]].events = READ_EVENTS;
		}
	    }
	}
    }

    ::close(lfd);
    return 0;
}
