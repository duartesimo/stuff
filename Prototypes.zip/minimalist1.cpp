// g++ -std=c++98 -Wall -Wextra -Werror poll_one.cpp -o poll_one
// Run: ./poll_one 6667
// Test: nc 127.0.0.1 6667

#include <iostream>
#include <string>
#include <cstring>
#include <cstdlib>
#include <cerrno>
#include <unistd.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <poll.h>

static bool set_nonblock(int fd) {
    int flags = fcntl(fd, F_GETFL, 0);
    if (flags < 0) return false;
    return fcntl(fd, F_SETFL, flags | O_NONBLOCK) == 0;
}

int main(int argc, char** argv)
{
    if (argc != 2) { std::cerr << "Usage: " << argv[0] << " <port>\n"; return 1; }
    int port = std::atoi(argv[1]);

    // 1) listening socket (IPv4, TCP)
    int lfd = socket(AF_INET, SOCK_STREAM, 0);

    int yes = 1;
    setsockopt(lfd, SOL_SOCKET, SO_REUSEADDR, &yes, sizeof(yes));

    sockaddr_in addr; std::memset(&addr, 0, sizeof(addr));
    addr.sin_family = AF_INET;
    addr.sin_addr.s_addr = htonl(INADDR_ANY);
    addr.sin_port = htons(port);

    bind(lfd, (sockaddr*)&addr, sizeof(addr));
    listen(lfd, 16);
    set_nonblock(lfd);

    // 2) poll set: just two entries (listener + optional client)
    pollfd pfds[2];
    pfds[0].fd = lfd;          // listener
    pfds[0].events = POLLIN;   // watch for new connections
    pfds[0].revents = 0;

    int cfd = -1;              // client fd (once accepted)
    pfds[1].fd = -1;           // inactive at start
    pfds[1].events = 0;
    pfds[1].revents = 0;

    std::string inbuf;         // partial input from client
    std::string outbuf;        // pending output to client

    std::cout << "Listening on port " << port << " (single client, poll)\n";

    while (true) {
	int nfds = (cfd >= 0) ? 2 : 1;      // only poll active fds
	int n = poll(pfds, nfds, 1000);     // wait up to 1s
	if (n <= 0) continue;               // timeout or interrupted

	// A) front door: accept first client (if not connected yet)
	if ((pfds[0].revents & POLLIN) && cfd < 0) {
	    sockaddr_in caddr; socklen_t clen = sizeof(caddr);
	    int newfd = accept(lfd, (sockaddr*)&caddr, &clen);
	    if (newfd >= 0) {
		set_nonblock(newfd);
		cfd = newfd;
		pfds[1].fd = cfd;
		pfds[1].events = POLLIN; // start by reading only
		pfds[1].revents = 0;
		outbuf += "Welcome! (single client)\r\n";
		pfds[1].events = POLLIN | POLLOUT; // we have something to send
	    }
	}

	// B) client side (if connected)
	if (cfd >= 0) {
	    short rev = pfds[1].revents;

	    // B1) readable: drain what the kernel has now (non-blocking)
	    if (rev & POLLIN) {
		char tmp[4096];
		while (true) {
		    ssize_t r = recv(cfd, tmp, sizeof(tmp), 0);
		    if (r > 0) {
			inbuf.append(tmp, (size_t)r);
		    } else if (r == 0) {
			// peer closed
			close(cfd);
			cfd = -1; pfds[1].fd = -1; pfds[1].events = 0; pfds[1].revents = 0;
			inbuf.clear(); outbuf.clear();
			break;
		    } else {
			if (errno == EAGAIN || errno == EWOULDBLOCK) break; // nothing more now
			// error
			close(cfd);
			cfd = -1; pfds[1].fd = -1; pfds[1].events = 0; pfds[1].revents = 0;
			inbuf.clear(); outbuf.clear();
			break;
		    }
		}
		// turn complete lines into echoes
		if (cfd >= 0) {
		    std::string::size_type pos = 0;
		    while (true) {
			std::string::size_type nl = inbuf.find('\n', pos);
			if (nl == std::string::npos) break;
			std::string line = inbuf.substr(pos, nl - pos);
			if (!line.empty() && line[line.size()-1] == '\r') line.erase(line.size()-1);
			outbuf += "you said: " + line + "\r\n";
			pos = nl + 1;
		    }
		    if (pos > 0) inbuf.erase(0, pos);
		    if (!outbuf.empty()) pfds[1].events = POLLIN | POLLOUT;
		}
	    }

	    // B2) writable: flush as much as possible
	    if (rev & POLLOUT) {
		while (!outbuf.empty()) {
		    ssize_t nwr = send(cfd, outbuf.data(), outbuf.size(), 0);
		    if (nwr > 0) {
			outbuf.erase(0, (size_t)nwr);
		    } else if (nwr < 0) {
			if (errno == EAGAIN || errno == EWOULDBLOCK) break; // try later
			// error
			close(cfd);
			cfd = -1; pfds[1].fd = -1; pfds[1].events = 0; pfds[1].revents = 0;
			inbuf.clear(); outbuf.clear();
			break;
		    } else {
			// nwr == 0 → treat as closed
			close(cfd);
			cfd = -1; pfds[1].fd = -1; pfds[1].events = 0; pfds[1].revents = 0;
			inbuf.clear(); outbuf.clear();
			break;
		    }
		}
		// if nothing left to send, stop watching POLLOUT
		if (cfd >= 0 && outbuf.empty()) {
		    pfds[1].events = POLLIN;
		}
	    }
	}

	// clear revents for next poll
	if (pfds[0].fd >= 0) pfds[0].revents = 0;
	if (pfds[1].fd >= 0) pfds[1].revents = 0;
    }

    close(lfd);
    return 0;
}
