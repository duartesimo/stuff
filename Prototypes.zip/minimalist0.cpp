#include <iostream>
#include <string>
#include <cstring>      // memset
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h> // sockaddr_in
#include <unistd.h>     // close

int main()
{
	// 1. Create a socket (IPv4, TCP)
	int server_fd = socket(AF_INET, SOCK_STREAM, 0);

	// 2. Bind it to 127.0.0.1:6667
	sockaddr_in addr;
	std::memset(&addr, 0, sizeof(addr));
	addr.sin_family = AF_INET;
	addr.sin_addr.s_addr = INADDR_ANY;  // any local address
	addr.sin_port = htons(6667);        // port 6667

	bind(server_fd, (sockaddr*)&addr, sizeof(addr));

	// 3. Start listening
	listen(server_fd, 5);

	std::cout << "Server listening on port 6667...\n";

	// 4. Accept one client
	sockaddr_in client_addr;
	socklen_t client_len = sizeof(client_addr);
	int client_fd = accept(server_fd, (sockaddr*)&client_addr, &client_len);

	std::cout << "Client connected!\n";

	// 5. Receive data (blocking)
	char buffer[1024];
	int n = recv(client_fd, buffer, sizeof(buffer)-1, 0);
	buffer[n] = '\0'; // make it a string
	std::cout << "Received: " << buffer << "\n";

	// 6. Send back a reply
	std::string reply = "Hello client!\n";
	send(client_fd, reply.c_str(), reply.size(), 0);

	// 7. Close sockets
	close(client_fd);
	close(server_fd);

	return 0;
}