#!/bin/bash

# Stop if error
set -e

# Add a new user and set password only if user does not exist
if ! id "$FTP_USER" &>/dev/null; then
	adduser --gecos "" $FTP_USER
	echo "$FTP_USER:$FTP_PASS" | chpasswd
fi

# Create user directory and give ownership
mkdir -p /home/$FTP_USER/ftp
chown -R "$FTP_USER:$FTP_USER" /home/$FTP_USER/ftp

# Add user token to vsftpd configuration
echo "user_sub_token=$FTP_USER" >> /etc/vsftpd.conf;

# Point vsftpd at the correct chroot (jail users into home directory, cant wander around)
echo "local_root=/home/$FTP_USER/ftp" >> /etc/vsftpd.conf;

# Authorize the user in vsftpd’s userlist
echo "$FTP_USER" | tee -a /etc/vsftpd.userlist;

exec "$@"