*This project has been created as part of the 42 curriculum by nsimao-f.*

# Inception

## Description

This project is a small containerized infrastructure built with Docker Compose and designed to run inside a Virtual Machine.

It's a secure and modular self-hosted web platform based on:
- **NGINX** as the only public entrypoint, exposed on port **443** with **TLSv1.2 / TLSv1.3**.
- **WordPress + PHP-FPM** as the application service.
- **MariaDB** as the database service.
- Persistent storage for both the database and the WordPress files.
- A dedicated Docker network used for inter-container communication.

This repository also includes several bonus services:
- **Redis** for WordPress object caching.
- **FTP** to access the WordPress volume.
- **Adminer** for database administration.
- **A static website**.
- **cAdvisor** for container monitoring.

The goal of the project is to learn how to build and orchestrate containers manually, write custom Dockerfiles, manage data persistence, isolate services correctly, and expose only the required entrypoint.

## Instructions

### Prerequisites
- A Linux Virtual Machine.
- Docker installed.
- Docker Compose available through `docker compose`.
- Permission to run Docker commands.
- A local domain mapping for `nsimao-f.42.fr` pointing to the VM IP address.

### Build and run
From the root of the repository:

```bash
make
```

Useful commands:

```bash
make up
make down
make clean
make fclean
make restart
```

### Access
- Main website: `https://nsimao-f.42.fr`
- WordPress admin panel: `https://nsimao-f.42.fr/wp-admin`
- Bonus static website: `http://<VM_IP>:8080`
- Adminer: `http://<VM_IP>:8081`
- cAdvisor: `http://<VM_IP>:8082`
- FTP: port `21` with passive ports `40000-40005`

### Repository structure

```text
.
├── Makefile
├── README.md
├── USER_DOC.md
├── DEV_DOC.md
└── srcs
    ├── .env
    ├── docker-compose.yml
    └── requirements
        ├── mariadb
        ├── nginx
        ├── wordpress
        └── bonus
            ├── adminer
            ├── cadvisor
            ├── ftp
            ├── redis
            └── website
```

## Resources
- Docker documentation
- Docker Compose documentation
- NGINX documentation
- MariaDB documentation
- WordPress documentation
- WP-CLI documentation
- PHP-FPM documentation
- Redis documentation
- 42 Inception subject and peer-evaluation material


## Project description

### Services included

#### Mandatory services
- **nginx**: reverse proxy and TLS termination.
- **wordpress**: PHP-FPM service running the WordPress application.
- **mariadb**: relational database used by WordPress.

#### Bonus services
- **redis**: cache backend for WordPress.
- **ftp**: access to the WordPress files volume.
- **website**: simple static site.
- **adminer**: database administration UI.
- **cadvisor**: container metrics and monitoring.

### Main design choices
- Each service runs in its **own dedicated container**.
- Images are built from custom **Dockerfiles** instead of using ready-made service images.
- The stack is orchestrated with **Docker Compose**.
- Data persists through two Docker-managed volumes mapped to `/home/nsimao-f/data` on the host.
- Only **NGINX** is exposed as the main entrypoint for the mandatory infrastructure.
- Environment variables are centralized in `srcs/.env`.
- The project is started through the **Makefile**, which prepares the host data directories and launches the stack.


## Required comparisons

### Virtual Machines vs Docker
- A **Virtual Machine** virtualizes an entire operating system, including its own kernel abstraction, which makes it heavier but more isolated.
- **Docker** virtualizes at the container level and shares the host kernel, making startup faster and resource usage lower.
- In this project, the VM is required by the subject, while Docker is used inside that VM to isolate services efficiently.

### Secrets vs Environment Variables
- **Environment variables** are convenient for configuration values such as domain names, usernames, ports, and application settings.
- **Secrets** are better suited for sensitive values such as passwords because they reduce accidental exposure and can be mounted more safely than plain text variables.
- This project uses environment variables from `.env` for simplicity.

### Docker Network vs Host Network
- A **Docker bridge network** isolates containers while still allowing them to communicate using service names such as `wordpress`, `mariadb`, or `redis`.
- **Host networking** removes that isolation and directly shares the host network stack, which is forbidden in this project.
- Using a dedicated Docker network keeps the architecture cleaner, more portable, and closer to production practices.

### Docker Volumes vs Bind Mounts
- **Docker volumes** are managed by Docker and are meant for persistent application data.
- **Bind mounts** map a host path directly into a container and are often used for development or direct host file access.
- For this project, persistence is required for the database and WordPress files, so dedicated persistent storage is used for those services.