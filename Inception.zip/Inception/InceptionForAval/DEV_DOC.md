# DEV_DOC

## Purpose

This document explains how a developer can set up, build, run, and maintain the project from scratch.

## Project overview

The stack is orchestrated with Docker Compose and built from custom Dockerfiles. The project contains three mandatory services and multiple bonus services.

### Mandatory
- `nginx`
- `wordpress`
- `mariadb`

### Bonus
- `redis`
- `ftp`
- `website`
- `adminer`
- `cadvisor`

## Prerequisites
- A Linux Virtual Machine.
- Docker installed and running.
- Docker Compose available through the `docker compose` command.
- Sudo privileges or permission to access the Docker daemon.
- A local hosts or DNS configuration mapping `nsimao-f.42.fr` to the VM IP.

## Environment setup from scratch

### 1. Clone the repository

```bash
git clone <repository_url>
cd <repository_directory>
```

### 2. Prepare configuration values
Edit:

```text
srcs/.env
```

This file contains the runtime configuration used by the services, including:
- `DOMAIN_NAME`
- database configuration values;
- WordPress administrator/user values;
- Redis configuration;
- FTP-related values if required by the bonus part.

### 3. Prepare the host persistent directories
The `Makefile` creates these automatically, but the expected persistent storage path is:

```text
/home/nsimao-f/data
```

Subdirectories used by the current project:
- `/home/nsimao-f/data/mysql`
- `/home/nsimao-f/data/wordpress`

## Build and launch

### Standard project startup
From the repository root:

```bash
make
```

This runs:
- creation of the host data directories;
- `docker compose up --build -d` using `srcs/docker-compose.yml`.

### Other Makefile targets

```bash
make up
make down
make clean
make fclean
make restart
```

## Direct Docker Compose commands
The project uses:

```bash
docker compose -f ./srcs/docker-compose.yml
```

Examples:

```bash
docker compose -f ./srcs/docker-compose.yml ps
docker compose -f ./srcs/docker-compose.yml logs
docker compose -f ./srcs/docker-compose.yml up --build -d
docker compose -f ./srcs/docker-compose.yml down
```

## Container and volume management

### List containers

```bash
docker compose -f ./srcs/docker-compose.yml ps
```

### View service logs

```bash
docker compose -f ./srcs/docker-compose.yml logs nginx
docker compose -f ./srcs/docker-compose.yml logs wordpress
docker compose -f ./srcs/docker-compose.yml logs mariadb
```

### Open a shell inside a container

```bash
docker exec -it nginx sh
docker exec -it wordpress sh
docker exec -it mariadb sh
```

### Inspect volumes

```bash
docker volume ls
docker volume inspect wordpress
docker volume inspect mariadb
```

### Remove containers and volumes

```bash
make clean
```

### Remove everything, including local persisted data

```bash
make fclean
```

## Data persistence

The project persists data across container recreation.

### Database data
Stored in:

```text
/home/nsimao-f/data/mysql
```

Mounted into the MariaDB container at:

```text
/var/lib/mysql
```

### WordPress files
Stored in:

```text
/home/nsimao-f/data/wordpress
```

Mounted into the WordPress and NGINX containers at:

```text
/var/www/html
```

This ensures that website files and database data are preserved when containers are stopped or recreated.

## Important implementation notes

### NGINX
- Exposes port `443`.
- Uses TLS.
- Connects to PHP-FPM in the `wordpress` container over the Docker network.

### WordPress
- Uses WP-CLI during initialization.
- Connects to MariaDB.
- Configures Redis cache in the current implementation.
- Exposes PHP-FPM internally on port `9000`.

### MariaDB
- Initializes the database directory on first start.
- Creates the application database and user through an init SQL script.

## Typical development workflow

### Rebuild after editing a Dockerfile or startup script

```bash
make build
```

### Recreate only the containers without deleting persistent data

```bash
make down
make up
```

### Start from a clean state

```bash
make fclean
make
```

## Troubleshooting

### The website does not open
- Verify that `nsimao-f.42.fr` resolves to the VM IP.
- Check that the `nginx` container is running.
- Inspect NGINX logs.

### WordPress cannot connect to the database
- Check `mariadb` logs.
- Verify the database-related variables in `.env`.
- Confirm that persistent data is not carrying an old incompatible configuration.

### Changes in `.env` do not seem to apply
- Some settings are only used on the first initialization.
- If needed, remove persistent data and rebuild:

```bash
make fclean
make
```
