# USER_DOC

## Purpose

This document explains how to use and operate the infrastructure from a user or administrator point of view.

## Services provided by the stack

### Mandatory services
- **NGINX**: serves as the HTTPS entrypoint.
- **WordPress + PHP-FPM**: provides the website and administration panel.
- **MariaDB**: stores the WordPress data.

### Bonus services
- **Redis**: WordPress cache backend.
- **FTP**: file access to the WordPress data volume.
- **Adminer**: browser-based MariaDB administration.
- **Static website**: bonus showcase website.
- **cAdvisor**: monitoring interface for containers.

## How to start the project
From the repository root:

```bash
make
```

If the project was already built and you only want to start it again:

```bash
make up
```

## How to stop the project

```bash
make down
```

To stop the project and remove volumes:

```bash
make clean
```

To stop everything and also remove the host data directory:

```bash
make fclean
```

## How to access the website

### Main website
Open:

```text
https://nsimao-f.42.fr
```

Because NGINX is configured with TLS, the website must be accessed through **HTTPS**.

### WordPress administration panel
Open:

```text
https://nsimao-f.42.fr/wp-admin
```

Then log in with the WordPress administrator credentials configured in the environment file.

## Where credentials are located
Project credentials are configured through:

```text
srcs/.env
```

Typical values stored there include:
- database name;
- database username;
- database password;
- MariaDB root password;
- WordPress administrator username/password/email;
- regular WordPress user username/password/email;
- Redis host and port;
- domain name.

If credentials are changed, the affected services may need to be rebuilt or the persistent data reset, depending on the change.

## Persistent data location
The project stores persistent data in:

```text
/home/nsimao-f/data
```

The main subdirectories are:
- `/home/nsimao-f/data/mysql`
- `/home/nsimao-f/data/wordpress`

These directories are created by the `Makefile` before the stack is started.

## How to check whether services are running correctly

### Check running containers

```bash
docker compose -f srcs/docker-compose.yml ps
```

### Check logs

```bash
docker compose -f srcs/docker-compose.yml logs
```

To inspect one specific service:

```bash
docker compose -f srcs/docker-compose.yml logs nginx
docker compose -f srcs/docker-compose.yml logs wordpress
docker compose -f srcs/docker-compose.yml logs mariadb
```

### Check the website
- Confirm that `https://nsimao-f.42.fr` loads.
- Confirm that the WordPress login page opens.
- Confirm that content persists after `docker compose down` / `up`.

### Check bonus services
- Adminer: `http://<VM_IP>:8081`
- Static website: `http://<VM_IP>:8080`
- cAdvisor: `http://<VM_IP>:8082`
- FTP: port `21`

## Basic administration tasks

### Restart the full stack

```bash
make restart
```

### Rebuild the stack

```bash
make build
```

### Remove all data and rebuild from scratch

```bash
make fclean
make
```
