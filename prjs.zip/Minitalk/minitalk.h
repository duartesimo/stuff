/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   minitalk.h                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: nsimao-f <nsimao-f@student.42porto.co>     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/11/29 11:29:28 by nsimao-f          #+#    #+#             */
/*   Updated: 2023/11/29 11:29:28 by nsimao-f         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef MINITALK_H
# define MINITALK_H

# define _XOPEN_SOURCE 500
# include "Libft/libft.h"
# include "Ft_Printf/ft_printf.h"
# include <signal.h>
# include <sys/types.h>
# include <uchar.h>

#endif
