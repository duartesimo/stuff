/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   client_bonus.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: nsimao-f <nsimao-f@student.42porto.co>     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/11/29 11:29:18 by nsimao-f          #+#    #+#             */
/*   Updated: 2023/11/29 11:29:18 by nsimao-f         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "minitalk.h"

void	send_letter(pid_t pid, char letter)
{
	int	i;

	i = 0;
	while (i < 8)
	{
		if ((letter & (0x01 << i)) != 0)
			kill(pid, SIGUSR1);
		else
			kill(pid, SIGUSR2);
		usleep(200);
		i++;
	}
}

void	sent(int sig, siginfo_t *info, void *cont)
{
	(void) info;
	(void) cont;
	if (sig == SIGUSR1)
		ft_printf("Your Message Was Received\n");
}

void	validate_args(int argc, char **argv)
{
	int	i;

	i = 0;
	if (argc != 3)
	{
		ft_printf("ERROR: Invalid number of arguments!\n");
		ft_printf("Try: ./client [server PID] [message]\n");
		exit(1);
	}
	while (argv[1][i])
	{
		if (!ft_isdigit(argv[1][i++]))
		{
			ft_printf("Invalid PID\n");
			exit(1);
		}
	}
}

int	main(int argc, char **argv)
{
	pid_t				pid; 
	char				*str;
	struct sigaction	sig;

	sig.sa_sigaction = &sent;
	sig.sa_flags = SA_SIGINFO;
	sigaction(SIGUSR1, &sig, NULL);
	validate_args(argc, argv);
	pid = (pid_t)ft_atoi(argv[1]); 
	str = argv[2];
	while (*str) 
	{
		send_letter(pid, *str); 
		str++; 
	}
	send_letter(pid, '\0');
	send_letter(pid, '\n');
	return (0); 
}
