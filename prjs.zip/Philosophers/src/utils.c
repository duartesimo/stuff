/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   utils.c                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: nsimao-f <nsimao-f@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/02/12 15:59:39 by nsimao-f          #+#    #+#             */
/*   Updated: 2024/08/24 11:10:29 by nsimao-f         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../philo.h"

void	error_exit(char *str)
{
	printf("%s\n", str);
	exit(EXIT_FAILURE);
}

void	link_philos_death_check(t_program *philo, t_program *check_deaths)
{
	int	i;

	i = -1;
	while (++i < check_deaths->philo_num)
		philo[i].program_mutex = check_deaths->program_mutex;
	check_deaths->start_time = get_time();
}

long long	get_time(void)
{
	struct timeval	time;

	if (gettimeofday(&time, NULL))
		error_exit("Get Time Failed!");
	return ((time.tv_sec * 1000) + (time.tv_usec / 1000));
}

void	better_usleep(long long sleep_time)
{
	long long	start;

	start = get_time();
	while (get_time() - start < sleep_time)
		usleep(100);
}

void	destroy_program(t_program *philo, t_program *check_deaths)
{
	int	i;

	i = -1;
	better_usleep(700);
	while (++i < philo->philo_num)
		pthread_mutex_destroy(&philo[i].fork_mutex[i]);
	pthread_mutex_destroy(check_deaths->program_mutex);
	free(philo->fork_mutex);
	free(philo->meals);
	free(philo->last_meal);
	free(philo->program_mutex);
	free(philo);
	free(check_deaths);
}
