/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   init_data.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: nsimao-f <nsimao-f@student.42porto.com>    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/02/12 15:58:08 by nsimao-f          #+#    #+#             */
/*   Updated: 2024/08/23 14:54:26 by nsimao-f         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../philo.h"

t_program	*init_death_check(t_program *program)
{
	t_program	*check_deaths;

	check_deaths = malloc(sizeof(t_program));
	if (!check_deaths)
		error_exit("Memory allocation failed for death check structure");
	check_deaths->id = 0;
	check_deaths->meals = program->meals;
	check_deaths->last_meal = program->last_meal;
	check_deaths->max_meals = program->max_meals;
	check_deaths->time_to_eat = program->time_to_eat;
	check_deaths->time_to_sleep = program->time_to_sleep;
	check_deaths->time_to_die = program->time_to_die;
	check_deaths->philo_num = program->philo_num;
	check_deaths->num_forks = program->philo_num;
	check_deaths->fork_mutex = NULL;
	check_deaths->program_mutex = malloc(sizeof(pthread_mutex_t));
	if (!check_deaths->program_mutex)
	{
		free(check_deaths);
		error_exit("Memory allocation failed for program mutex in death check");
	}
	pthread_mutex_init(check_deaths->program_mutex, NULL);
	return (check_deaths);
}

static void	init_philos_helper(t_program *program, t_program *philos, \
		long long *last_meal, pthread_mutex_t *forks)
{
	int	i;
	int	*meals;

	meals = malloc(sizeof(int) * program->philo_num);
	if (!meals)
		return ;
	memset(meals, 0, sizeof(int) * program->philo_num);
	i = 0;
	while (i < program->philo_num)
	{
		philos[i].id = i + 1;
		philos[i].meals = meals;
		philos[i].last_meal = last_meal;
		philos[i].max_meals = program->max_meals;
		philos[i].time_to_eat = program->time_to_eat;
		philos[i].time_to_sleep = program->time_to_sleep;
		philos[i].time_to_die = program->time_to_die;
		philos[i].philo_num = program->philo_num;
		philos[i].num_forks = program->philo_num;
		philos[i].fork_mutex = forks;
		i++;
	}
}

static void	*init_philos(t_program *program, t_program *philos)
{
	int				i;
	long long		*last_meal;
	pthread_mutex_t	*forks;

	forks = malloc(sizeof(pthread_mutex_t) * program->philo_num);
	last_meal = malloc(sizeof(long long) * program->philo_num);
	if (!forks || !last_meal)
		return (NULL);
	i = 0;
	while (i < program->philo_num)
	{
		pthread_mutex_init(&forks[i], NULL);
		last_meal[i] = get_time();
		i++;
	}
	init_philos_helper(program, philos, last_meal, forks);
	free(program);
	return (NULL);
}

t_program	*init_data(char **argv)
{
	t_program	*program;
	t_program	*philos;

	program = malloc(sizeof(t_program));
	if (!program)
		error_exit("Memory allocation failed for program structure");
	if (!parse_args(program, argv))
	{
		free(program);
		error_exit("Argument parsing failed");
	}
	philos = malloc(sizeof(t_program) * program->philo_num);
	if (!philos)
	{
		free(program);
		error_exit("Memory allocation failed for philosophers");
	}
	init_philos(program, philos);
	return (philos);
}
