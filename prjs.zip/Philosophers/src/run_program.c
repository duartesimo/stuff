/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   run_program.c                                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: nsimao-f <nsimao-f@student.42porto.com>    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/02/12 15:58:37 by nsimao-f          #+#    #+#             */
/*   Updated: 2024/08/23 23:43:06 by nsimao-f         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../philo.h"

static bool	philo_full(t_program *check_deaths)
{
	int	i;

	i = 0;
	if (check_deaths->max_meals == -1)
		return (false);
	while (i < check_deaths->philo_num)
	{
		pthread_mutex_lock(check_deaths->program_mutex);
		if (check_deaths->meals[i] < check_deaths->max_meals)
			return (pthread_mutex_unlock(check_deaths->program_mutex), false);
		pthread_mutex_unlock(check_deaths->program_mutex);
		i++;
	}
	pthread_mutex_lock(check_deaths->program_mutex);
	return (true);
}

static void	*monitor_deaths(void *data)
{
	int				i;
	long long		now;
	t_program		*check_deaths;

	check_deaths = (t_program *)data;
	i = 0;
	better_usleep(20);
	while (i < check_deaths->philo_num && !philo_full(check_deaths))
	{
		pthread_mutex_lock(check_deaths->program_mutex);
		now = get_time() - check_deaths->last_meal[i];
		pthread_mutex_unlock(check_deaths->program_mutex);
		if (now >= check_deaths->time_to_die)
		{
			pthread_mutex_lock(check_deaths->program_mutex);
			printf("%-6lld %d died\n", get_time() \
				- check_deaths->start_time, i + 1);
			return (NULL);
		}
		if (i + 1 == check_deaths->philo_num)
			i = -1;
		i++;
	}
	return (NULL);
}

static void	*philosopher_routine(void *data)
{
	t_program	*philo;

	philo = (t_program *)data;
	if (philo->id % 2 == 0)
		better_usleep(20);
	while (true)
	{
		grab_forks(philo);
		print_message(philo, 'e');
		better_usleep(philo->time_to_eat);
		release_forks(philo);
		print_message(philo, 's');
		better_usleep(philo->time_to_sleep);
		print_message(philo, 't');
	}
	return (NULL);
}

void	run_program(t_program *philo, t_program *check_deaths)
{
	int	i;

	i = 0;
	while (i < philo->philo_num)
	{
		philo[i].start_time = get_time();
		pthread_create(&philo[i].philo_thread, NULL,
			philosopher_routine, &philo[i]);
		pthread_detach(philo[i].philo_thread);
		i++;
	}
	pthread_create(&check_deaths->philo_thread, NULL,
		monitor_deaths, check_deaths);
	pthread_join(check_deaths->philo_thread, NULL);
}
