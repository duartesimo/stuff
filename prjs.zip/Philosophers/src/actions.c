/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   actions.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: nsimao-f <nsimao-f@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/02/12 15:58:55 by nsimao-f          #+#    #+#             */
/*   Updated: 2024/08/24 11:10:23 by nsimao-f         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../philo.h"

void	grab_forks(t_program *philo)
{
	pthread_mutex_lock(&philo->fork_mutex[philo->id - 1]);
	if (philo->id == 1)
		pthread_mutex_lock(&philo->fork_mutex[philo->philo_num - 1]);
	else
		pthread_mutex_lock(&philo->fork_mutex[philo->id - 2]);
	print_message(philo, 'f');
}

void	release_forks(t_program *philo)
{
	pthread_mutex_unlock(&philo->fork_mutex[philo->id - 1]);
	if (philo->id == 1)
		pthread_mutex_unlock(&philo->fork_mutex[philo->philo_num - 1]);
	else
		pthread_mutex_unlock(&philo->fork_mutex[philo->id - 2]);
}
