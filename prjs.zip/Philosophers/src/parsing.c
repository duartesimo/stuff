/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   parsing.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: nsimao-f <nsimao-f@student.42porto.com>    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/02/12 15:56:42 by nsimao-f          #+#    #+#             */
/*   Updated: 2024/08/23 12:52:58 by nsimao-f         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../philo.h"

static const char	*valid_str(const char *str)
{
	long		len;
	const char	*number;

	len = 0;
	while ((*str >= 9 && *str <= 13) || *str == ' ')
		++str;
	if (*str == '+')
		++str;
	else if (*str == '-')
		error_exit("Number can't be negative");
	if (!(*str >= '0' && *str <= '9'))
		error_exit("Input must be digits");
	number = str;
	while (*str >= '0' && *str <= '9')
	{
		++str;
		++len;
	}
	if (len > 10)
		error_exit("Number is too big");
	return (number);
}

static int	ft_atoi(const char *str)
{
	long	num;

	num = 0;
	str = valid_str(str);
	while (*str >= '0' && *str <= '9')
	{
		num = (num * 10) + (*str - '0');
		str++;
	}
	if (num > INT_MAX)
		error_exit("Number is too big");
	return ((int)num);
}

bool	parse_args(t_program *program, char **argv)
{
	program->philo_num = ft_atoi(argv[1]);
	program->time_to_die = ft_atoi(argv[2]);
	program->time_to_eat = ft_atoi(argv[3]);
	program->time_to_sleep = ft_atoi(argv[4]);
	if (argv[5])
		program->max_meals = ft_atoi(argv[5]);
	else
		program->max_meals = -1;
	if (program->philo_num == 0)
		return (error_exit("Add at least one philosopher"), false);
	if (program->time_to_die < 60 || program->time_to_eat < 60 || \
		program->time_to_sleep < 60)
		return (error_exit("Time must be more than 60ms"), false);
	if (program->max_meals == 0)
		return (error_exit("Add at least one meal"), false);
	return (true);
}
