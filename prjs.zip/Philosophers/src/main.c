/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: nsimao-f <nsimao-f@student.42porto.com>    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/02/12 15:55:37 by nsimao-f          #+#    #+#             */
/*   Updated: 2024/08/24 00:20:03 by nsimao-f         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../philo.h"

int	main(int argc, char *argv[])
{
	t_program	*philos;
	t_program	*check_deaths;

	if (argc != 5 && argc != 6)
		error_exit("Invalid arguments\nTry ./philo 5 800 200 200 (max_meals)");
	philos = init_data(argv);
	check_deaths = init_death_check(philos);
	link_philos_death_check(philos, check_deaths);
	run_program(philos, check_deaths);
	destroy_program(philos, check_deaths);
	return (0);
}
