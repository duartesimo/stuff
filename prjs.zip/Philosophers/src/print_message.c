/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   print_message.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: nsimao-f <nsimao-f@student.42porto.com>    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/02/12 15:59:47 by nsimao-f          #+#    #+#             */
/*   Updated: 2024/08/23 20:08:49 by nsimao-f         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../philo.h"

static const char	*get_color(int id)
{
	const char	*colors[8];

	colors[0] = "\033[31m";
	colors[1] = "\033[32m";
	colors[2] = "\033[33m";
	colors[3] = "\033[34m";
	colors[4] = "\033[35m";
	colors[5] = "\033[36m";
	colors[6] = "\033[37m";
	colors[7] = "\033[90m";
	return (colors[(id - 1) % 8]);
}

void	print_message(t_program *philo, char status)
{
	long long	now;
	const char	*color;

	color = get_color(philo->id);
	now = get_time() - philo->start_time;
	pthread_mutex_lock(philo->program_mutex);
	if (status == 'f')
	{
		printf("%-6lld %s%d has taken a fork\033[0m\n", now, color, philo->id);
		printf("%-6lld %s%d has taken a fork\033[0m\n", now, color, philo->id);
	}
	else if (status == 'e')
	{
		printf("%-6lld \033[1m%s%d is eating\033[0m\n", now, color, philo->id);
		philo->last_meal[philo->id - 1] = get_time();
		philo->meals[philo->id - 1]++;
	}
	else if (status == 's')
		printf("%-6lld %s%d is sleeping\033[0m\n", now, color, philo->id);
	else if (status == 't')
		printf("%-6lld %s%d is thinking\033[0m\n", now, color, philo->id);
	pthread_mutex_unlock(philo->program_mutex);
}
