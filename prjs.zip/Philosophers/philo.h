/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   philo.h                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: nsimao-f <nsimao-f@student.42porto.com>    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/02/12 15:57:12 by nsimao-f          #+#    #+#             */
/*   Updated: 2024/08/23 20:36:46 by nsimao-f         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef PHILO_H
# define PHILO_H

# include <unistd.h>
# include <stdio.h>
# include <string.h>
# include <stdlib.h>
# include <stdbool.h>
# include <limits.h>
# include <pthread.h>
# include <sys/time.h>

typedef struct s_program
{
	int				id;
	int				philo_num;
	int				*meals;
	int				max_meals;
	int				time_to_eat;
	int				time_to_sleep;
	int				time_to_die;
	int				num_forks;
	long long		start_time;
	long long		*last_meal;
	pthread_t		philo_thread;
	pthread_mutex_t	*fork_mutex;
	pthread_mutex_t	*program_mutex;
}	t_program;

/* Program */
bool			parse_args(t_program *program, char **argv);
void			run_program(t_program *philo, t_program *check_deaths);
void			destroy_program(t_program *philo, t_program *check_deaths);

/* Init Values */
t_program		*init_data(char **argv);
t_program		*init_death_check(t_program *program);
void			link_philos_death_check(t_program *philo, \
			t_program *check_deaths);

/* Actions */
void			grab_forks(t_program *philo);
void			release_forks(t_program *philo);

/* Utils */
void			print_message(t_program *philo, char status);
void			error_exit(char *str);
void			better_usleep(long long sleep_time);
long long		get_time(void);

#endif
