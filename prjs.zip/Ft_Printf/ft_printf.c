/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_printf.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: nsimao-f <nsimao-f@student.42porto.co      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/10/17 10:21:39 by nsimao-f          #+#    #+#             */
/*   Updated: 2023/10/17 10:21:43 by nsimao-f         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft_printf.h"

int	print_format(char special, va_list args)
{
	int	count;

	count = 0;
	if (special == 'c')
		count += ft_putchar(va_arg(args, int));
	else if (special == 's')
		count += ft_putstr(va_arg(args, char *));
	else if (special == 'd' || special == 'i')
		count += ft_putnbr((va_arg(args, int)), "0123456789");
	else if (special == 'u')
		count += ft_putnbr((va_arg(args, unsigned int)), "0123456789");
	else if (special == 'p')
	{
		count += ft_putptr(va_arg(args, unsigned long long));
	}
	else if (special == 'x')
		count += ft_putnbr((va_arg(args, unsigned int)), "0123456789abcdef");
	else if (special == 'X')
		count += ft_putnbr((va_arg(args, unsigned int)), "0123456789ABCDEF");
	else if (special == '%')
		count += ft_putchar('%');
	return (count);
}

int	ft_printf(const char *format, ...)
{
	int			count;
	int			i;
	va_list		args;

	va_start(args, format);
	count = 0;
	i = 0;
	while (format[i])
	{
		if (format[i] == '%')
		{
			i++;
			count += print_format(format[i], args);
		}
		else
			count += ft_putchar(format[i]);
		i++;
	}
	va_end(args);
	return (count);
}

/* #include <stdio.h>
#include <limits.h>
int main()
{
        char ch = 'A';
        char str[] = "Hello, world!";
        int num = -2147483648;
        unsigned int unsigned_num = 4294967295;
        void *ptr = (void *)main;
        int hex_num = -2147483648;
        int Hex_num = 2147483647;
        int count = 0;

        // Test %c (character)
        count = ft_printf("%%c: %c\n", ch);
        ft_printf("%d\n", count);
        count = printf("%%c: %c\n", ch);
        printf("%d\n", count);
        ft_printf("\n");

        // Test %s (string)
        count = ft_printf("%%s: %s\n", str);
        ft_printf("%d\n", count);
        count = printf("%%s: %s\n", str);
        printf("%d\n", count);
        ft_printf("\n");

        // Test %d and %i (decimal and integer)
        count = ft_printf("%%d and %%i: %d, %i\n", num, num);
        ft_printf("%d\n", count);
        count = printf("%%d and %%i: %d, %i\n", num, num);
        printf("%d\n", count);
        ft_printf("\n");

        // Test %u (unsigned integer)
        count = ft_printf("%%u: %u\n", unsigned_num);
        ft_printf("%d\n", count);
        count = printf("%%u: %u\n", unsigned_num);
        printf("%d\n", count);
        ft_printf("\n");

        // Test %p (pointer)
        count = ft_printf("%%p: %p  %p\n", 0, 0);
        ft_printf("%d\n", count);
        count = printf("%%p: %p  %p\n", 0, 0);
        printf("%d\n", count);
        ft_printf("\n");

        // Test %x (lowercase hexadecimal)
        count = ft_printf("%%x: %x\n", hex_num);
        ft_printf("%d\n", count);
        count = printf("%%x: %x\n", hex_num);
        printf("%d\n", count);
        ft_printf("\n");

        // Test %X (uppercase hexadecimal)
        count = ft_printf("%%X: %X\n", Hex_num);
        ft_printf("%d\n", count);
        count = printf("%%X: %X\n", Hex_num);
        printf("%d\n", count);
        ft_printf("\n");

        // Test %%
        count = ft_printf("%%%%\n");
        ft_printf("%d\n", count);
        count = printf("%%%%\n");
        printf("%d\n", count);
        ft_printf("\n");

        return 0;
}
 */