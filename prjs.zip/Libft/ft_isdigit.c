/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_isdigit.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: nsimao-f <nsimao-f@student.42porto.co>     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/10/17 12:06:31 by nsimao-f          #+#    #+#             */
/*   Updated: 2023/10/17 12:06:31 by nsimao-f         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

int	ft_isdigit(int c)
{
	if (c >= '0' && c <= '9')
		return (1);
	return (0);
}

/*
#include <stdio.h>
int main()
{
    char str[] = "1 2a.-*8";
    int count = 0;
 
    for (int i = 0; str[i] != '\0'; i++) 
        if (ft_isdigit(str[i]) != 0)
		count++;
    printf("Count = %d", count);
}
*/