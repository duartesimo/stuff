/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   split.c                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: nsimao-f <nsimao-f@student.42porto.co>     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/12/18 15:09:34 by nsimao-f          #+#    #+#             */
/*   Updated: 2023/12/18 15:09:34 by nsimao-f         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "push_swap.h"

static int	count_words(char *str, char space)
{
	int	i;
	int	word;

	i = 0;
	while (*str)
	{
		word = 0;
		while (*str == space)
			str++;
		while (*str != space && *str)
		{
			if (!word)
			{
				i++;
				word = 1;
			}
			str++;
		}
	}
	return (i);
}

static char	*get_next_word(char *str, char space)
{
	static int	pointer = 0;
	char		*word;
	int			len;
	int			i;

	len = 0;
	i = 0;
	while (str[pointer] == space)
		++pointer;
	while ((str[pointer + len] != space) && str[pointer + len])
		++len;
	word = malloc((size_t)len * sizeof(char) + 1);
	if (!word)
		return (NULL);
	while ((str[pointer] != space) && str[pointer])
		word[i++] = str[pointer++];
	word[i] = '\0';
	return (word);
}

char	**ft_split(char *s, char c)
{
	int		words;
	char	**strings;
	int		i;

	i = 0;
	words = count_words(s, c);
	if (!words)
		exit(1);
	strings = malloc(sizeof(char *) * (size_t)(words + 2));
	if (!strings)
		return (NULL);
	while (words-- >= 0)
	{
		if (i == 0)
		{
			strings[i] = malloc(sizeof(char));
			if (!strings[i])
				return (NULL);
			strings[i++][0] = '\0';
			continue ;
		}
		strings[i++] = get_next_word(s, c);
	}
	strings[i] = NULL;
	return (strings);
}
