/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   create_stack.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: nsimao-f <nsimao-f@student.42porto.co>     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/12/06 14:53:26 by nsimao-f          #+#    #+#             */
/*   Updated: 2023/12/06 14:53:26 by nsimao-f         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "push_swap.h"

void	add_node(t_stack **stack, int num)
{
	t_stack	*node;
	t_stack	*last_node;

	if (!stack)
		return ;
	node = (t_stack *) malloc(sizeof(t_stack));
	if (!node)
		return ;
	node->next = NULL;
	node->value = num;
	node->cheapest = 0;
	if (!(*stack))
	{
		*stack = node;
		node->prev = NULL;
	}
	else
	{
		last_node = get_last_node(*stack);
		last_node->next = node;
		node->prev = last_node;
	}
}

void	start_stack(t_stack **stack, char **argv, int argc2)
{
	int		i;
	long	num;

	i = 0;
	while (argv[i])
	{
		if (error_syntax(argv[i]))
			free_errors(stack, argv, argc2);
		num = ft_atol(argv[i]);
		if (num > INT_MAX || num < INT_MIN)
			free_errors(stack, argv, argc2);
		if (error_duplicate(*stack, (int)num))
			free_errors(stack, argv, argc2);
		add_node(stack, (int)num);
		i++;
	}
	if (argc2)
		free_matrix(argv);
}
