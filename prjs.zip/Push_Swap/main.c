/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: nsimao-f <nsimao-f@student.42porto.co>     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/12/06 14:53:12 by nsimao-f          #+#    #+#             */
/*   Updated: 2023/12/06 14:53:12 by nsimao-f         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "push_swap.h"

int	main(int argc, char **argv)
{
	t_stack	*stack_a;
	t_stack	*stack_b;

	stack_a = NULL;
	stack_b = NULL;
	if (argc == 1)
		return (1);
	else if (argc == 2 && !argv[1][0])
		exit_stuff();
	else if (argc == 2)
		argv = ft_split(argv[1], ' ');
	start_stack(&stack_a, argv + 1, argc == 2);
	if (!is_sorted_stack(stack_a))
	{
		if (length_stack(stack_a) == 2)
			sa(&stack_a, 1);
		else if (length_stack(stack_a) == 3)
			sort_three(&stack_a);
		else
			sort_stacks(&stack_a, &stack_b);
	}
	free_stack(&stack_a);
	return (0);
}
