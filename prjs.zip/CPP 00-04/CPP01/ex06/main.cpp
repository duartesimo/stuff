#include "Harl.hpp"

int main(int argc, char *argv[])
{
	if (argc != 2)
	{
		std::cerr << "Try: " << argv[0] << " <level>" << std::endl;
		return (1);
	}
	
	Harl harl;
	harl.filter(argv[1]);

	return (0);
}