#include "AMateria.hpp"
#include "ICharacter.hpp"

AMateria::AMateria(std::string const & type) : _type(type) {
    std::cout << "AMateria of type " << _type << " created at " << this << std::endl;
}

AMateria::~AMateria() {
    std::cout << "AMateria of type " << _type << " destroyed at " << this << std::endl;
}

std::string const & AMateria::getType() const
{
	return _type;
}

void AMateria::use(ICharacter& target)
{
	std::cout << "* uses an undefined Materia on " << target.getName() << " *" << std::endl;
}
