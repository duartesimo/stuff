#include "Ice.hpp"

Ice::Ice() : AMateria("ice") {
    std::cout << "Ice Materia created at " << this << std::endl;
}

Ice::~Ice() {
    std::cout << "Ice Materia destroyed at " << this << std::endl;
}

AMateria* Ice::clone() const {
    std::cout << "Cloning Ice Materia at " << this << std::endl;
    return new Ice(*this);
}

void Ice::use(ICharacter& target)
{
	std::cout << "* shoots an ice bolt at " << target.getName() << " *" << std::endl;
}
