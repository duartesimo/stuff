#include "Cure.hpp"

Cure::Cure() : AMateria("cure") {
    std::cout << "Cure Materia created at " << this << std::endl;
}

Cure::~Cure() {
    std::cout << "Cure Materia destroyed at " << this << std::endl;
}

AMateria* Cure::clone() const {
    std::cout << "Cloning Cure Materia at " << this << std::endl;
    return new Cure(*this);
}

void Cure::use(ICharacter& target)
{
	std::cout << "* heals " << target.getName() << "'s wounds *" << std::endl;
}
