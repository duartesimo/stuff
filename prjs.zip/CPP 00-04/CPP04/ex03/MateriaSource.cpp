#include "MateriaSource.hpp"

MateriaSource::MateriaSource() {
    std::cout << "MateriaSource created at " << this << std::endl;
    for (int i = 0; i < 4; ++i)
        _templates[i] = NULL;
}

MateriaSource::~MateriaSource() {
    std::cout << "MateriaSource destroyed at " << this << std::endl;
    for (int i = 0; i < 4; ++i) {
        if (_templates[i])
            delete _templates[i];
    }
}
void MateriaSource::learnMateria(AMateria* m) {
    for (int i = 0; i < 4; ++i) {
        if (!_templates[i]) {
            _templates[i] = m->clone();
            std::cout << "Learned " << m->getType() << " Materia at slot " << i << " in MateriaSource" << std::endl;
            return;
        }
    }
}

AMateria* MateriaSource::createMateria(std::string const & type) {
    for (int i = 0; i < 4; ++i) {
        if (_templates[i] && _templates[i]->getType() == type) {
            std::cout << "Creating Materia of type " << type << " from MateriaSource at " << this << std::endl;
            return _templates[i]->clone();
        }
    }
    std::cout << "Materia of type " << type << " not found in MateriaSource at " << this << std::endl;
    return NULL;
}
