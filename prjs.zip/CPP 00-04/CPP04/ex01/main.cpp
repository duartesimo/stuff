#include "Animal.hpp"
#include "Brain.hpp"
#include "Dog.hpp"
#include "Cat.hpp"

int main()
{
	const int count = 4;
	Animal* animals[count];

	for (int i = 0; i < count / 2; ++i)
		animals[i] = new Dog();
	

	for (int i = count / 2; i < count; ++i)
		animals[i] = new Cat();
	

	for (int i = 0; i < count; ++i)
		animals[i]->makeSound();
	
	for (int i = 0; i < count; ++i)
		delete animals[i];
}