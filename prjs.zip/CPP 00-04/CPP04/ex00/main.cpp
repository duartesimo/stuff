#include "Animal.hpp"
#include "Cat.hpp"
#include "Dog.hpp"
#include "WrongAnimal.hpp"
#include "WrongCat.hpp"

int main()
{
	const Animal* meta = new Animal();
	const Animal* j = new Dog();
	const Animal* i = new Cat();
	
	std::cout << j->getType() << " " << std::endl;
	std::cout << i->getType() << " " << std::endl;
	i->makeSound();  // Cat sound
	j->makeSound();  // Dog sound
	meta->makeSound(); // Animal sound

	delete meta;
	delete j;
	delete i;

	std::cout << "\nTesting with WrongAnimal and WrongCat:" << std::endl;
	const WrongAnimal* wrongMeta = new WrongAnimal();
	const WrongAnimal* wrongCat = new WrongCat();

	std::cout << wrongCat->getType() << " " << std::endl;
	wrongCat->makeSound();  // Wrong animal sound
	wrongMeta->makeSound(); // Wrong animal sound

	delete wrongMeta;
	delete wrongCat;

	return (0);
}